# Dharini_wmn
# A web app that can help improve the conditions of Sex workers.

Sex workers are not taken care of and respected in society. We have tried to build such a project that will help them curb their mental health and loneliness, as well as they can know about their health by inputing symptoms. The GPS tracker is included for the Security of sex workers.

It contains three components:
'''
Machine learning model for disease-prediction which helps the user input symptoms and the model predicts the disease, if any.
Chatbot: To reduce loneliness and depression among them
GPS Tracker that ensures if the zone is safe or not!!
'''
## Technologies used:

Javascript
HTML/CSS
Flask
Machine Learning
dialogflow
Here (GeoFencing)
